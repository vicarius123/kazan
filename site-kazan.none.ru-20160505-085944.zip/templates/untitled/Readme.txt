===========
Contents
===========

*** Installing Joomla Template
---------------------------------------

To install the exported and zipped template via Joomla administration panel please do the following:
1. Go to Joomla Administrator (www.your-site.com/administrator) -> Extensions -> Install/Uninstall.
2. In the "Extension Manager" choose the first option "Upload Package File".
3. Click the "Choose..." button to select the zip file from your computer.
4. Click the "Upload File & Install" button.

For more information please visit http://docs.joomla.org/How_to_install_templates